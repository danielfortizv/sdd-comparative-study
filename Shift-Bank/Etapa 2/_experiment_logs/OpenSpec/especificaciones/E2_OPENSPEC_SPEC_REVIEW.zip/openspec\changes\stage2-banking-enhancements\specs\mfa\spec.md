## ADDED Requirements

### Requirement: Preserve MFA contract across transfer types
The existing MFA threshold of COP 1,000,000 or more, fixed six-digit code `123456`, five-minute expiration, invalid-code retry behavior, and expiration status behavior MUST remain unchanged for sensitive internal and ACH transfers. No transfer may debit funds before successful MFA authorization.

#### Scenario: Sensitive ACH uses inherited MFA contract
- **WHEN** user initiates an otherwise valid ACH transfer of at least COP 1,000,000
- **THEN** it requires the existing MFA code and expiration behavior before acceptance and debit

#### Scenario: Internal transfer MFA regression
- **WHEN** user initiates and confirms a sensitive internal transfer using the existing correct code within five minutes
- **THEN** the transfer retains the existing Stage 1 confirmation behavior and executes only after authorization and current validation

### Requirement: Authorize sensitive recurring schedules at creation
Creation of a recurring schedule with an amount of COP 1,000,000 or more MUST require the inherited MFA verification during creation. The schedule MUST NOT become active until valid verification succeeds within five minutes. Successful creation-time verification authorizes automatic future executions for that schedule without another interactive MFA prompt, but does not override execution-time balance or limit checks. Financial parameters are immutable after successful creation; changed terms require a new schedule and applicable MFA.

#### Scenario: Sensitive schedule requires creation-time MFA
- **WHEN** user creates a recurring schedule for COP 1,000,000 or more
- **THEN** it remains inactive until the existing MFA code is verified within the existing expiration window

#### Scenario: Automatic execution needs no interactive MFA
- **WHEN** an MFA-authorized recurring schedule becomes due and current balance and limits pass
- **THEN** the system executes automatically without prompting the user again

#### Scenario: Schedule MFA does not bypass current limits
- **WHEN** a previously authorized schedule becomes due but its amount would exceed a current transfer limit
- **THEN** the occurrence fails without debit
